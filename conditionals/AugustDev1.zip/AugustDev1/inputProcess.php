<?php
    $name = $_POST["fullName"];

    echo "Hello " .$name;

?>