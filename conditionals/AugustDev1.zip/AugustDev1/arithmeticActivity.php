<?php
    //1. create 10 variables
    //2. give integer values to your 10 variables
    //3. perform the following:
        //addition on num1 and num2
        //subtraction on num3 and num4
        //multiplication on num5 and num6
        //division on num7 and num8
        //modulo on num9 and num10
    //4. display the results

    $num1 = 100;
    $num2 = 45;
    $num3 = 5;
    $num4 = 19;
    $num5 = 38;
    $num6 = 97;
    $num7 = 34;
    $num8 = 22;
    $num9 = 9;
    $num10 = 20;

    $sum = $num1 + $num2;
    $diff = $num3 - $num4;
    $prod = $num5 * $num6;
    $quo = $num7 / $num8;
    $rem = $num9 % $num10;

    echo "Addtion: " .$sum. "<br>";
    echo "Subtraction: " .$diff. "<br>";
    echo "Multiplication: " .$prod. "<br>";
    echo "Division: " .$quo. "<br>";
    echo "Modulo: " .$rem. "<br>";

?>