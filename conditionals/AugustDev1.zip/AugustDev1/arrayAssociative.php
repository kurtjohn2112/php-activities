<?php
    $person = array("Name"=>"Mary", "age"=>28, "address"=>"USA", "food"=>"burger");

    foreach($person as $variableToSAveTheValue){
        echo " " .$variableToSAveTheValue;
    }

?>