<?php
    //1. create 2 variables and give an integer value to each variable
    //2. create 1 variable and give/assign a country(value)
    //3. create 1 variable and give a decimal value to the variable
    //4. display the values of the variables (echo)

    $num1 = 50;
    $num2 = 12;
    $country = "Philippines";
    $amount = 105.75;

    echo "Num1 " .$num1. "<br>";
    echo "Num2 " .$num2. "<br>";
    echo "Country " .$country. "<br>";
    echo "Amount " .$amount. "<br>";

?>