<?php
    $num = 5; //integer
    $name = "Mary"; //string
    $price = 25.38; //float
    $gender = "f"; //char

    //display the values
    echo "The value in num variable is: " .$num. "<br>";
    //echo "The value in num varaible is $num <br>";
    
    echo "The value in name variable is: " .$name. "<br>";
    echo "The value in price variable is: " .$price. "<br>";
    echo "The value in gender variable is: " .$gender. "<br>";
?>